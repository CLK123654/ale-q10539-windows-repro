# 客服SLA日历与升级队列

support_sla.db保存工单和暂停事件，business_calendar.json给出Asia/Shanghai工作日历、统计截止时间、各优先级SLA阈值及升级团队。starter/rebuild_sla.sql是待完成的SQLite脚本，这三份材料都会参与结算。

在input_data目录完成starter脚本后执行：

    npm run process

入口会把完成SQL交付到output/sql/rebuild_sla.sql，并由SQLite生成修复库、SLA时钟、暂停区间审计和升级队列。输出供客服运营、班组主管、升级值班组和数据工程人员继续使用。
