import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const inputRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const runRoot = path.dirname(inputRoot);
const outputRoot = path.join(runRoot, "output");
const sourceSql = path.join(inputRoot, "starter", "rebuild_sla.sql");
const deliverySql = path.join(outputRoot, "sql", "rebuild_sla.sql");
const sqlite = process.env.SQLITE_BIN || "sqlite3";

fs.rmSync(outputRoot, { recursive: true, force: true });
if (!fs.existsSync(sourceSql) || !fs.existsSync(path.join(inputRoot, "support_sla.db")) || !fs.existsSync(path.join(inputRoot, "business_calendar.json"))) {
  console.error("缺少客服SLA结算材料");
  process.exit(2);
}
const sql = fs.readFileSync(sourceSql, "utf8");
if (/请在这里完成|\bTODO\b/.test(sql)) {
  console.error("客服SLA重建脚本尚未完成");
  process.exit(2);
}
fs.mkdirSync(path.join(outputRoot, "reports"), { recursive: true });
fs.mkdirSync(path.join(outputRoot, "sql"), { recursive: true });
fs.copyFileSync(path.join(inputRoot, "support_sla.db"), path.join(outputRoot, "support_sla_repaired.db"));
fs.writeFileSync(deliverySql, sql, "utf8");
const result = spawnSync(sqlite, [], {
  cwd: runRoot,
  input: sql,
  encoding: "utf8",
  windowsHide: true,
  timeout: 120000
});
if (result.error || result.status !== 0) {
  fs.rmSync(outputRoot, { recursive: true, force: true });
  if (result.error) console.error(result.error.message);
  else console.error(result.stderr || result.stdout);
  process.exit(result.status ?? 1);
}
for (const relative of [
  "support_sla_repaired.db",
  "sql/rebuild_sla.sql",
  "reports/sla_clock.csv",
  "reports/pause_interval_audit.csv",
  "reports/breach_queue.csv"
]) {
  if (!fs.existsSync(path.join(outputRoot, relative))) {
    fs.rmSync(outputRoot, { recursive: true, force: true });
    console.error(`缺少客服SLA业务交付：${relative}`);
    process.exit(1);
  }
}
