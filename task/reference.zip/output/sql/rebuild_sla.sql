.bail on
.open output/support_sla_repaired.db

PRAGMA foreign_keys = ON;
ATTACH DATABASE 'input_data/support_sla.db' AS original_input;

DROP TABLE IF EXISTS pause_interval_audit;
DROP TABLE IF EXISTS sla_clock;
DROP TABLE IF EXISTS breach_queue;
DROP TABLE IF EXISTS temp._calendar_json;
DROP TABLE IF EXISTS temp._guard;
DROP TABLE IF EXISTS temp._workday;
DROP TABLE IF EXISTS temp._holiday;
DROP TABLE IF EXISTS temp._threshold;
DROP TABLE IF EXISTS temp._route;
DROP TABLE IF EXISTS temp._pause_pair;
DROP TABLE IF EXISTS temp._work_minute;
DROP TABLE IF EXISTS temp._ticket_metrics;

CREATE TEMP TABLE _calendar_json(doc TEXT NOT NULL);
INSERT INTO _calendar_json(doc)
SELECT CAST(readfile('input_data/business_calendar.json') AS TEXT);

CREATE TEMP TABLE _guard(ok INTEGER NOT NULL CHECK(ok = 1));
INSERT INTO _guard
SELECT CASE WHEN json_valid(doc)
  AND json_type(doc, '$.as_of_local') = 'text'
  AND json_type(doc, '$.workdays') = 'array'
  AND json_type(doc, '$.holidays') = 'array'
  AND json_type(doc, '$.sla_minutes') = 'object'
  AND json_type(doc, '$.escalation_team_by_priority') = 'object'
  AND json_extract(doc, '$.timezone') = 'Asia/Shanghai'
  THEN 1 ELSE 0 END
FROM _calendar_json;

CREATE TEMP TABLE _workday(weekday_code TEXT PRIMARY KEY, weekday_name TEXT UNIQUE);
INSERT INTO _workday
SELECT CASE value
         WHEN 'Sun' THEN '0' WHEN 'Mon' THEN '1' WHEN 'Tue' THEN '2'
         WHEN 'Wed' THEN '3' WHEN 'Thu' THEN '4' WHEN 'Fri' THEN '5'
         WHEN 'Sat' THEN '6'
       END,
       value
FROM _calendar_json, json_each(doc, '$.workdays');

CREATE TEMP TABLE _holiday(holiday_date TEXT PRIMARY KEY);
INSERT INTO _holiday
SELECT value FROM _calendar_json, json_each(doc, '$.holidays');

CREATE TEMP TABLE _threshold(priority TEXT PRIMARY KEY, sla_minutes INTEGER NOT NULL CHECK(sla_minutes >= 0));
INSERT INTO _threshold
SELECT key, CAST(value AS INTEGER)
FROM _calendar_json, json_each(doc, '$.sla_minutes');

CREATE TEMP TABLE _route(priority TEXT PRIMARY KEY, escalation_team TEXT NOT NULL);
INSERT INTO _route
SELECT key, value
FROM _calendar_json, json_each(doc, '$.escalation_team_by_priority');

INSERT INTO _guard
SELECT CASE WHEN NOT EXISTS (
  SELECT 1
  FROM tickets t
  LEFT JOIN _threshold s ON s.priority = t.priority
  LEFT JOIN _route r ON r.priority = t.priority
  WHERE s.priority IS NULL OR r.priority IS NULL
) THEN 1 ELSE 0 END;

CREATE TEMP TABLE _pause_pair AS
WITH starts AS (
  SELECT event_id,
         ticket_id,
         event_time AS pause_start,
         reason AS start_reason,
         ROW_NUMBER() OVER (PARTITION BY ticket_id ORDER BY event_time, event_id) AS pair_number
  FROM ticket_events
  WHERE event_type = 'pause_start'
),
ends AS (
  SELECT event_id,
         ticket_id,
         event_time AS pause_end,
         reason AS end_reason,
         ROW_NUMBER() OVER (PARTITION BY ticket_id ORDER BY event_time, event_id) AS pair_number
  FROM ticket_events
  WHERE event_type = 'pause_end'
)
SELECT s.ticket_id,
       s.pair_number,
       s.pause_start,
       e.pause_end,
       s.start_reason,
       e.end_reason
FROM starts s
LEFT JOIN ends e USING(ticket_id, pair_number);

INSERT INTO _guard
SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM _pause_pair WHERE pause_end IS NULL OR pause_end <= pause_start
) AND (SELECT COUNT(*) FROM ticket_events WHERE event_type = 'pause_end') = (SELECT COUNT(*) FROM _pause_pair)
THEN 1 ELSE 0 END;

CREATE TEMP TABLE _work_minute(minute_start TEXT PRIMARY KEY);
WITH RECURSIVE minute_axis(minute_start, max_minute) AS (
  SELECT MIN(opened_at),
         MAX(CASE WHEN status = 'resolved' THEN resolved_at ELSE json_extract((SELECT doc FROM _calendar_json), '$.as_of_local') END)
  FROM tickets
  UNION ALL
  SELECT datetime(minute_start, '+1 minute'), max_minute
  FROM minute_axis
  WHERE minute_start < max_minute
)
INSERT INTO _work_minute(minute_start)
SELECT minute_start
FROM minute_axis
WHERE minute_start < max_minute
  AND strftime('%w', minute_start) IN (SELECT weekday_code FROM _workday)
  AND date(minute_start) NOT IN (SELECT holiday_date FROM _holiday)
  AND strftime('%H:%M', minute_start) >= json_extract((SELECT doc FROM _calendar_json), '$.work_start')
  AND strftime('%H:%M', minute_start) < json_extract((SELECT doc FROM _calendar_json), '$.work_end');

CREATE TABLE pause_interval_audit(
  ticket_id TEXT NOT NULL,
  pause_start TEXT NOT NULL,
  pause_end TEXT NOT NULL,
  start_reason TEXT NOT NULL,
  end_reason TEXT NOT NULL,
  business_pause_minutes INTEGER NOT NULL,
  interval_state TEXT NOT NULL,
  PRIMARY KEY(ticket_id, pause_start)
);
INSERT INTO pause_interval_audit
SELECT p.ticket_id,
       p.pause_start,
       p.pause_end,
       p.start_reason,
       p.end_reason,
       (SELECT COUNT(*) FROM _work_minute w WHERE w.minute_start >= p.pause_start AND w.minute_start < p.pause_end),
       'closed'
FROM _pause_pair p
ORDER BY p.ticket_id, p.pause_start;

CREATE TEMP TABLE _ticket_metrics AS
WITH measured AS (
  SELECT t.*,
         CASE WHEN t.status = 'resolved'
              THEN t.resolved_at
              ELSE json_extract((SELECT doc FROM _calendar_json), '$.as_of_local')
         END AS measured_until
  FROM tickets t
),
gross AS (
  SELECT m.*,
         (SELECT COUNT(*) FROM _work_minute w
          WHERE w.minute_start >= m.opened_at AND w.minute_start < m.measured_until) AS gross_business_minutes
  FROM measured m
),
paused AS (
  SELECT g.*,
         COALESCE((
           SELECT COUNT(*)
           FROM _work_minute w
           JOIN _pause_pair p ON p.ticket_id = g.ticket_id
           WHERE w.minute_start >= g.opened_at
             AND w.minute_start < g.measured_until
             AND w.minute_start >= p.pause_start
             AND w.minute_start < p.pause_end
         ), 0) AS paused_business_minutes
  FROM gross g
)
SELECT p.*,
       p.gross_business_minutes - p.paused_business_minutes AS business_elapsed_minutes,
       s.sla_minutes AS sla_threshold_minutes
FROM paused p
JOIN _threshold s USING(priority);

CREATE TABLE sla_clock(
  ticket_id TEXT PRIMARY KEY,
  priority TEXT NOT NULL,
  status TEXT NOT NULL,
  opened_at TEXT NOT NULL,
  measured_until TEXT NOT NULL,
  business_elapsed_minutes INTEGER NOT NULL,
  paused_business_minutes INTEGER NOT NULL,
  sla_threshold_minutes INTEGER NOT NULL,
  breach_minutes INTEGER NOT NULL,
  sla_state TEXT NOT NULL
);
INSERT INTO sla_clock
SELECT ticket_id,
       priority,
       status,
       opened_at,
       measured_until,
       business_elapsed_minutes,
       paused_business_minutes,
       sla_threshold_minutes,
       MAX(business_elapsed_minutes - sla_threshold_minutes, 0),
       CASE WHEN business_elapsed_minutes > sla_threshold_minutes THEN 'breached' ELSE 'within_sla' END
FROM _ticket_metrics
ORDER BY ticket_id;

CREATE TABLE breach_queue(
  queue_rank INTEGER PRIMARY KEY,
  ticket_id TEXT NOT NULL UNIQUE,
  priority TEXT NOT NULL,
  breach_minutes INTEGER NOT NULL,
  escalation_team TEXT NOT NULL,
  enqueue_reason TEXT NOT NULL
);
INSERT INTO breach_queue
SELECT ROW_NUMBER() OVER (ORDER BY s.breach_minutes DESC, s.ticket_id),
       s.ticket_id,
       s.priority,
       s.breach_minutes,
       r.escalation_team,
       s.priority || ' SLA exceeded by ' || s.breach_minutes || ' business minutes'
FROM sla_clock s
JOIN _route r USING(priority)
WHERE s.sla_state = 'breached'
ORDER BY s.breach_minutes DESC, s.ticket_id;

.headers on
.mode csv
.once output/reports/sla_clock.csv
SELECT ticket_id, priority, status, opened_at, measured_until, business_elapsed_minutes,
       paused_business_minutes, sla_threshold_minutes, breach_minutes, sla_state
FROM sla_clock ORDER BY ticket_id;

.once output/reports/breach_queue.csv
SELECT queue_rank, ticket_id, priority, breach_minutes, escalation_team, enqueue_reason
FROM breach_queue ORDER BY queue_rank;

.once output/reports/pause_interval_audit.csv
SELECT ticket_id, pause_start, pause_end, start_reason, end_reason, business_pause_minutes, interval_state
FROM pause_interval_audit ORDER BY ticket_id, pause_start;

DETACH DATABASE original_input;
